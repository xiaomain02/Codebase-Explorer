#!/bin/bash

check_count() {
    if [ $# -ne 1 ]; then
        echo "Ошибка: скрипт ожидает ровно один параметр. Передано аргументов: $#"
        exit 1
    fi
}

is_empty() {
    local str="$1"
    if [ -z "$str" ]; then
        echo "Ошибка: передан пустой параметр"
        exit 1
    fi
}

is_number() {
    local str="$1"
    if [[ "$str" =~ ^-?[0-9]+$ ]]; then
        echo "Ошибка: параметр должен быть текстовым"
        exit 1
    fi
}

input() {
    check_count "$@"
    is_empty "$1"
    is_number "$1"

    return 0
}