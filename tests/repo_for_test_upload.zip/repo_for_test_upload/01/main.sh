#!/bin/bash

source ./validate.sh

input "$@"

echo "$1"