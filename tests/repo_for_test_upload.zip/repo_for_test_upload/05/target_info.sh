#!/bin/bash

get_total_folders() {
    find "$1" -type d 2>/dev/null | wc -l
}

get_top_folders() {
    local i=1
    du -h "$1" 2>/dev/null | sort -hr | head -5 | while read size path; do
        path="${path%/}/"
        echo "$i - $path, $size"
        ((i++))
    done
}

get_total_files() {
    find "$1" -type f 2>/dev/null | wc -l
}

get_conf_files() {
    find "$1" -type f -name "*.conf" 2>/dev/null | wc -l
}

get_text_files() {
    find "$1" -type f -exec file --mime-type {} \; 2>/dev/null | grep -c "text/plain"
}

get_executable_files() {
    find "$1" -type f -executable 2>/dev/null | wc -l
}

get_log_files() {
    find "$1" -type f -name "*.log" 2>/dev/null | wc -l
}

get_archive_files() {
    find "$1" -type f 2>/dev/null | grep -E '\.(tar|gz|zip|7z|rar|bz2|xz|tgz)$' | wc -l
}

get_symlinks() {
    find "$1" -type l 2>/dev/null | wc -l
}

get_file_type() {
    local file="$1"
    
    if [[ "$file" == *.conf ]]; then
        echo "conf"
    elif [[ "$file" == *.log ]]; then
        echo "log"
    elif [[ "$file" == *.tar || "$file" == *.gz || "$file" == *.zip || "$file" == *.7z || "$file" == *.rar || "$file" == *.bz2 || "$file" == *.xz || "$file" == *.tgz ]]; then
        echo "archive"
    elif [ -x "$file" ]; then
        echo "exe"
    else
        local mime=$(file --mime-type -b "$file" 2>/dev/null)
        if [ "$mime" = "text/plain" ]; then
            echo "txt"
        else
            echo "${file##*.}"
        fi
    fi
}

get_top_files() {
    local i=1
    find "$1" -type f -exec ls -l {} \; 2>/dev/null | awk '{print $5, $NF}' | sort -nr | head -10 | while read size path; do
        type=$(get_file_type "$path")
        if [ $size -ge 1073741824 ]; then
            size_str=$(echo "scale=2; $size/1073741824" | bc)"G"
        elif [ $size -ge 1048576 ]; then
            size_str=$(echo "scale=2; $size/1048576" | bc)"M"
        elif [ $size -ge 1024 ]; then
            size_str=$(echo "scale=2; $size/1024" | bc)"K"
        else
            size_str="${size}B"
        fi
        echo "$i - $path, $size_str, $type"
        ((i++))
    done
}

get_top_executables() {
    local i=1
    find "$1" -type f -executable -exec ls -l {} \; 2>/dev/null | awk '{print $5, $NF}' | sort -nr | head -10 | while read size path; do
        md5=$(md5sum "$path" | cut -d' ' -f1)
        if [ $size -ge 1073741824 ]; then
            size_str=$(echo "scale=2; $size/1073741824" | bc)"G"
        elif [ $size -ge 1048576 ]; then
            size_str=$(echo "scale=2; $size/1048576" | bc)"M"
        elif [ $size -ge 1024 ]; then
            size_str=$(echo "scale=2; $size/1024" | bc)"K"
        else
            size_str="${size}B"
        fi
        echo "$i - $path, $size_str, $md5"
        ((i++))
    done
}