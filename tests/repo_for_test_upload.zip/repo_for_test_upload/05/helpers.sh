#!/bin/bash

check_utils() {
    local utils=("find" "du" "sort" "head" "nl" "sed" "grep" "wc" "file" "md5sum" "bc")
    for util in "${utils[@]}"; do
        if ! command -v "$util" &>/dev/null; then
            echo "Ошибка: необходимая утилита '$util' не найдена"
            exit 1
        fi
    done
}

check_args_count() {
    if [ $# -ne 1 ]; then
        echo "Ошибка: скрипт должен принимать ровно один параметр"
        exit 1
    fi
}

check_trailing_slash() {
    if [[ ! "$1" =~ /$ ]]; then
        echo "Ошибка: путь должен заканчиваться на '/'"
        exit 1
    fi
}

check_directory_exists() {
    if [ ! -d "$1" ]; then
        echo "Ошибка: указанный путь '$1' не является директорией или не существует." >&2
        exit 1
    fi
}

validate_input() {
    check_utils
    check_args_count "$@"
    check_trailing_slash "$1"
    check_directory_exists "$1"
}