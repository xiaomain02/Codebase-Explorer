#!/bin/bash

source ./target_info.sh
source ./helpers.sh

validate_input "$@"

target="$1"

start_time=$(date +%s.%N)

total_folders=$(get_total_folders "$target")

top_folders=$(get_top_folders "$target")

total_files=$(get_total_files "$target")

conf_files=$(get_conf_files "$target")
text_files=$(get_text_files "$target")
executable_files=$(get_executable_files "$target")
log_files=$(get_log_files "$target")
archive_files=$(get_archive_files "$target")
symlink_files=$(get_symlinks "$target")

top_files=$(get_top_files "$target")

top_executables=$(get_top_executables "$target")

end_time=$(date +%s.%N)
exec_time=$(echo "$end_time - $start_time" | bc)
exec_time_formatted=$(printf "%.1f" "$exec_time")

echo "Total number of folders (including all nested ones) = $total_folders"
echo "TOP 5 folders of maximum size arranged in descending order (path and size):"
echo "$top_folders"
echo "Total number of files = $total_files"
echo "Number of:"
echo "Configuration files (with the .conf extension) = $conf_files"
echo "Text files = $text_files"
echo "Executable files = $executable_files"
echo "Log files (with the extension .log) = $log_files"
echo "Archive files = $archive_files"
echo "Symbolic links = $symlink_files"
echo "TOP 10 files of maximum size arranged in descending order (path, size and type):"
echo "$top_files"
echo "TOP 10 executable files of the maximum size arranged in descending order (path, size and MD5 hash of file):"
echo "$top_executables"
echo "Script execution time (in seconds) = $exec_time_formatted"
