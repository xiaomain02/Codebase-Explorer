#!/bin/bash

source ./system_info.sh
source ./helpers.sh

check_no_args "$@"
check_utils

OUTPUT="HOSTNAME = $(get_hostname)
TIMEZONE = $(get_timezone)
USER = $(get_user)
OS = $(get_os)
DATE = $(get_date)
UPTIME = $(get_uptime)
UPTIME_SEC = $(get_uptime_sec)
IP = $(get_ip)
MASK = $(get_mask)
GATEWAY = $(get_gateway)
RAM_TOTAL = $(get_ram_total)
RAM_USED = $(get_ram_used)
RAM_FREE = $(get_ram_free)
SPACE_ROOT = $(get_space_root)
SPACE_ROOT_USED = $(get_space_root_used)
SPACE_ROOT_FREE = $(get_space_root_free)"

echo "$OUTPUT"

echo -n "Save to file? (Y/N): "
read -r answer

if [[ "$answer" =~ ^[Yy]$ ]]; then
    filename=$(date +"%d_%m_%y_%H_%M_%S").status
    echo "$OUTPUT" > "$filename"
    echo "Data saved to $filename"
else
    echo "Data not saved"
fi

exit 0