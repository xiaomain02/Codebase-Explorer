#!/bin/bash

get_hostname() {
    hostname
}

get_timezone() {
    local timezone=$(timedatectl show --property=Timezone --value)
    local utc=$(date +%z)
    echo "$timezone UTC ${utc:0:1}${utc:1:2}"
}

get_user() {
    whoami
}

get_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        echo "$PRETTY_NAME"
    else
        uname -o
    fi
}

get_date() {
    date +"%d %B %Y %H:%M:%S"
}

get_uptime() {
    uptime -p | sed 's/up //'
}

get_uptime_sec() {
    awk '{printf "%.0f", $1}' /proc/uptime
}

get_ip() {
    ip -4 addr show | grep inet | grep -v "127.0.0.1" | head -n 1 | awk '{print $2}' | cut -d'/' -f1
}

get_mask() {
    local mask_net=$(ip route | grep '/' | head -1 | cut -d' ' -f1)
    if [[ -n "$mask_net" ]] && command -v ipcalc &>/dev/null; then
        ipcalc "$mask_net" 2>/dev/null | grep 'Netmask' | cut -d' ' -f4
    else
        echo "N/A"
    fi
}

get_gateway() {
    ip route show default | awk '{print $3}' | head -n1
}

get_ram_total() {
    local bytes=$(free -b | awk '/^Mem:/ {print $2}')
    echo "$bytes" | awk '{printf "%.3f GB", $1/1073741824}'
}

get_ram_used() {
    local bytes=$(free -b | awk '/^Mem:/ {print $3}')
    echo "$bytes" | awk '{printf "%.3f GB", $1/1073741824}'
}

get_ram_free() {
    local bytes=$(free -b | awk '/^Mem:/ {print $4}')
    echo "$bytes" | awk '{printf "%.3f GB", $1/1073741824}'
}

get_space_root() {
    local bytes=$(df -B1 / | awk 'NR==2 {print $2}')
    echo "$bytes" | awk '{printf "%.2f MB", $1/1048576}'
}

get_space_root_used() {
    local bytes=$(df -B1 / | awk 'NR==2 {print $3}')
    echo "$bytes" | awk '{printf "%.2f MB", $1/1048576}'
}

get_space_root_free() {
    local bytes=$(df -B1 / | awk 'NR==2 {print $4}')
    echo "$bytes" | awk '{printf "%.2f MB", $1/1048576}'
}