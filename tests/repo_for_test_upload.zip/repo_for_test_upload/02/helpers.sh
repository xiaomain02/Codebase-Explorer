#!/bin/bash

check_no_args() {
    if [ $# -ne 0 ]; then
        echo "Ошибка: скрипт не принимает аргументов"
        exit 1
    fi
}

check_utils() {
    local utils=("timedatectl" "awk" "ip" "free" "df" "date" "uptime" "cat" "grep" "head" "cut" "ipcalc")
    for util in "${utils[@]}"; do
        if ! command -v "$util" &>/dev/null; then
            echo "Ошибка: необходимая утилита '$util' не найдена"
            exit 1
        fi
    done
}