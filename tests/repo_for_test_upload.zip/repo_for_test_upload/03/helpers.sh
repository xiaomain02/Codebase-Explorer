#!/bin/bash

check_utils() {
    local utils=("timedatectl" "awk" "ip" "free" "df" "date" "uptime" "cat" "grep" "head" "cut" "ipcalc")
    for util in "${utils[@]}"; do
        if ! command -v "$util" &>/dev/null; then
            echo "Ошибка: необходимая утилита '$util' не найдена"
            exit 1
        fi
    done
}

check_args() {
    if [ $# -ne 4 ]; then
        echo "Ошибка: скрипт требует ровно 4 числовых параметра (от 1 до 6)"
        exit 1
    fi

    for param in "$@"; do
        if ! [[ "$param" =~ ^[1-6]$ ]]; then
            echo "Ошибка: параметры должны быть числами от 1 до 6"
            exit 1
        fi
    done

    if [ "$1" -eq "$2" ]; then
        echo "Ошибка: цвет фона и шрифта названий не могут совпадать. Вызовите скрипт повторно"
        exit 1
    fi
    
    if [ "$3" -eq "$4" ]; then
        echo "Ошибка: цвет фона и шрифта значений не могут совпадать. Вызовите скрипт повторно"
        exit 1
    fi
}
