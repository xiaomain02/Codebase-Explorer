#!/bin/bash

source ./color.sh
source ./helpers.sh
source ./system_info.sh

check_utils
check_args "$@"

bg_left=$(get_bg_color "$1")
fg_left=$(get_fg_color "$2")
bg_right=$(get_bg_color "$3")
fg_right=$(get_fg_color "$4")

left_style="\033[${bg_left};${fg_left}m"
right_style="\033[${bg_right};${fg_right}m"

HOSTNAME=$(get_hostname)
TIMEZONE=$(get_timezone)
USER=$(get_user)
OS=$(get_os)
DATE=$(get_date)
UPTIME=$(get_uptime)
UPTIME_SEC=$(get_uptime_sec)
IP=$(get_ip)
MASK=$(get_mask)
GATEWAY=$(get_gateway)
RAM_TOTAL=$(get_ram_total)
RAM_USED=$(get_ram_used)
RAM_FREE=$(get_ram_free)
SPACE_ROOT=$(get_space_root)
SPACE_ROOT_USED=$(get_space_root_used)
SPACE_ROOT_FREE=$(get_space_root_free)

echo -e "${left_style}HOSTNAME${reset_color} = ${right_style}${HOSTNAME}${reset_color}"
echo -e "${left_style}TIMEZONE${reset_color} = ${right_style}${TIMEZONE}${reset_color}"
echo -e "${left_style}USER${reset_color} = ${right_style}${USER}${reset_color}"
echo -e "${left_style}OS${reset_color} = ${right_style}${OS}${reset_color}"
echo -e "${left_style}DATE${reset_color} = ${right_style}${DATE}${reset_color}"
echo -e "${left_style}UPTIME${reset_color} = ${right_style}${UPTIME}${reset_color}"
echo -e "${left_style}UPTIME_SEC${reset_color} = ${right_style}${UPTIME_SEC}${reset_color}"
echo -e "${left_style}IP${reset_color} = ${right_style}${IP}${reset_color}"
echo -e "${left_style}MASK${reset_color} = ${right_style}${MASK}${reset_color}"
echo -e "${left_style}GATEWAY${reset_color} = ${right_style}${GATEWAY}${reset_color}"
echo -e "${left_style}RAM_TOTAL${reset_color} = ${right_style}${RAM_TOTAL}${reset_color}"
echo -e "${left_style}RAM_USED${reset_color} = ${right_style}${RAM_USED}${reset_color}"
echo -e "${left_style}RAM_FREE${reset_color} = ${right_style}${RAM_FREE}${reset_color}"
echo -e "${left_style}SPACE_ROOT${reset_color} = ${right_style}${SPACE_ROOT}${reset_color}"
echo -e "${left_style}SPACE_ROOT_USED${reset_color} = ${right_style}${SPACE_ROOT_USED}${reset_color}"
echo -e "${left_style}SPACE_ROOT_FREE${reset_color} = ${right_style}${SPACE_ROOT_FREE}${reset_color}"

exit 0