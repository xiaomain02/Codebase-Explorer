#!/bin/bash

DEFAULT_COL1_BG=2
DEFAULT_COL1_FG=4
DEFAULT_COL2_BG=5
DEFAULT_COL2_FG=1

read_config() {
    local config_file="$1"
    [ -f "$config_file" ] || return 0

    while IFS='=' read -r key value; do
        key=$(echo "$key" | xargs)
        value=$(echo "$value" | xargs)

        [[ -z "$key" || "$key" == \#* ]] && continue

        case "$key" in
            column1_background)
                if [[ "$value" =~ ^[1-6]$ ]]; then
                    col1_bg="$value"
                    col1_bg_set=1
                fi
                ;;
            column1_font_color)
                if [[ "$value" =~ ^[1-6]$ ]]; then
                    col1_fg="$value"
                    col1_fg_set=1
                fi
                ;;
            column2_background)
                if [[ "$value" =~ ^[1-6]$ ]]; then
                    col2_bg="$value"
                    col2_bg_set=1
                fi
                ;;
            column2_font_color)
                if [[ "$value" =~ ^[1-6]$ ]]; then
                    col2_fg="$value"
                    col2_fg_set=1
                fi
                ;;
        esac
    done < "$config_file"
}

set_defaults() {
    [ $col1_bg_set -eq 0 ] && col1_bg="$DEFAULT_COL1_BG"
    [ $col1_fg_set -eq 0 ] && col1_fg="$DEFAULT_COL1_FG"
    [ $col2_bg_set -eq 0 ] && col2_bg="$DEFAULT_COL2_BG"
    [ $col2_fg_set -eq 0 ] && col2_fg="$DEFAULT_COL2_FG"
}