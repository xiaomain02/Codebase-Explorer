#!/bin/bash

check_utils() {
    local utils=("timedatectl" "awk" "ip" "free" "df" "date" "uptime" "cat" "grep" "head" "cut" "ipcalc")
    for util in "${utils[@]}"; do
        if ! command -v "$util" &>/dev/null; then
            echo "Ошибка: необходимая утилита '$util' не найдена"
            exit 1
        fi
    done
}

check_no_args() {
    if [ $# -ne 0 ]; then
        echo "Ошибка: скрипт не должен принимать параметров"
        exit 1
    fi
}

check_colors() {
    if [ "$1" -eq "$2" ]; then
        echo "Ошибка: цвет фона и шрифта названий не могут совпадать"
        exit 1
    fi
    
    if [ "$3" -eq "$4" ]; then
        echo "Ошибка: цвет фона и шрифта значений не могут совпадать"
        exit 1
    fi
}
