#!/bin/bash

source ./color.sh
source ./config.sh
source ./helpers.sh
source ./system_info.sh

check_utils
check_no_args "$@"

col1_bg=
col1_fg=
col2_bg=
col2_fg=
col1_bg_set=0
col1_fg_set=0
col2_bg_set=0
col2_fg_set=0

read_config ./config.txt

set_defaults

check_colors $col1_bg $col1_fg $col2_bg $col2_fg

left_bg_code=$(get_bg_color "$col1_bg")
left_fg_code=$(get_fg_color "$col1_fg")
right_bg_code=$(get_bg_color "$col2_bg")
right_fg_code=$(get_fg_color "$col2_fg")

left_style="\033[${left_bg_code};${left_fg_code}m"
right_style="\033[${right_bg_code};${right_fg_code}m"

HOSTNAME=$(get_hostname)
TIMEZONE=$(get_timezone)
USER=$(get_user)
OS=$(get_os)
DATE=$(get_date)
UPTIME=$(get_uptime)
UPTIME_SEC=$(get_uptime_sec)
IP=$(get_ip)
MASK=$(get_mask)
GATEWAY=$(get_gateway)
RAM_TOTAL=$(get_ram_total)
RAM_USED=$(get_ram_used)
RAM_FREE=$(get_ram_free)
SPACE_ROOT=$(get_space_root)
SPACE_ROOT_USED=$(get_space_root_used)
SPACE_ROOT_FREE=$(get_space_root_free)

echo -e "${left_style}HOSTNAME${reset_color} = ${right_style}${HOSTNAME}${reset_color}"
echo -e "${left_style}TIMEZONE${reset_color} = ${right_style}${TIMEZONE}${reset_color}"
echo -e "${left_style}USER${reset_color} = ${right_style}${USER}${reset_color}"
echo -e "${left_style}OS${reset_color} = ${right_style}${OS}${reset_color}"
echo -e "${left_style}DATE${reset_color} = ${right_style}${DATE}${reset_color}"
echo -e "${left_style}UPTIME${reset_color} = ${right_style}${UPTIME}${reset_color}"
echo -e "${left_style}UPTIME_SEC${reset_color} = ${right_style}${UPTIME_SEC}${reset_color}"
echo -e "${left_style}IP${reset_color} = ${right_style}${IP}${reset_color}"
echo -e "${left_style}MASK${reset_color} = ${right_style}${MASK}${reset_color}"
echo -e "${left_style}GATEWAY${reset_color} = ${right_style}${GATEWAY}${reset_color}"
echo -e "${left_style}RAM_TOTAL${reset_color} = ${right_style}${RAM_TOTAL}${reset_color}"
echo -e "${left_style}RAM_USED${reset_color} = ${right_style}${RAM_USED}${reset_color}"
echo -e "${left_style}RAM_FREE${reset_color} = ${right_style}${RAM_FREE}${reset_color}"
echo -e "${left_style}SPACE_ROOT${reset_color} = ${right_style}${SPACE_ROOT}${reset_color}"
echo -e "${left_style}SPACE_ROOT_USED${reset_color} = ${right_style}${SPACE_ROOT_USED}${reset_color}"
echo -e "${left_style}SPACE_ROOT_FREE${reset_color} = ${right_style}${SPACE_ROOT_FREE}${reset_color}"

echo

col1_bg_name=$(get_color_name "$col1_bg")
col1_fg_name=$(get_color_name "$col1_fg")
col2_bg_name=$(get_color_name "$col2_bg")
col2_fg_name=$(get_color_name "$col2_fg")

if [ $col1_bg_set -eq 1 ]; then
    echo "Column 1 background = $col1_bg ($col1_bg_name)"
else
    echo "Column 1 background = default ($col1_bg_name)"
fi

if [ $col1_fg_set -eq 1 ]; then
    echo "Column 1 font color = $col1_fg ($col1_fg_name)"
else
    echo "Column 1 font color = default ($col1_fg_name)"
fi

if [ $col2_bg_set -eq 1 ]; then
    echo "Column 2 background = $col2_bg ($col2_bg_name)"
else
    echo "Column 2 background = default ($col2_bg_name)"
fi

if [ $col2_fg_set -eq 1 ]; then
    echo "Column 2 font color = $col2_fg ($col2_fg_name)"
else
    echo "Column 2 font color = default ($col2_fg_name)"
fi